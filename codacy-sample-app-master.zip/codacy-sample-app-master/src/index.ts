const printName = (firstName: string, lastName: string) => {
    const fullName = firstName + " " + lastName;
    return fullName;
};
module.exports = printName;